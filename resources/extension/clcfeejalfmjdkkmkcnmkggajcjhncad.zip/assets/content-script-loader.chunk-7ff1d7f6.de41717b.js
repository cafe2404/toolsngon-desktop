(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-7ff1d7f6.js")
    );
  })().catch(console.error);

})();
