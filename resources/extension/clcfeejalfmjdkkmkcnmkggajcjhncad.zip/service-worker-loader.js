import './assets/chunk-dec0e0a6.js';
